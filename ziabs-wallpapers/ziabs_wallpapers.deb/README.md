<h2 style="text-align: center;">Random Wallpaper Changing App For Ubuntu Desktop<h2>

<a href="http://ziabs.com/ziabs-wallpapers/ziabs_wallpapers.deb"><h4>Download the App: &nbsp;&nbsp;http://ziabs.com/ziabs-wallpapers/ziabs_wallpapers.deb<h4></a>
<p>For Install : <i>sudo dpkg -i [PATH TO THE APP]/ziabs_wallpapers.deb</i></p>
<p>For Uninstall : <i>sudo /var/ziabsWallpapers/uninstall</i><p>

<a href="http://ziabs.com" style="margin-left: 45%;"><img src="https://raw.githubusercontent.com/ziabs/ziabs_ubuntu_wallpaper_changer/master/var/ziabsWallpapers/icons/rzwfwh.png" alt="ziAbs Ubuntu Desktop Wallpaper changer" width="100" height="100"></img></a>
